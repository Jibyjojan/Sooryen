# Sooryen Front-End Interview

Please clone this repository on your local computer and follow these steps:
- Add the repo to your own github profile
- Create a branch with your first name as the branch name
- Complete the test (see details below)
- Commit and Push to your branch

### Files:
- index.html
- style.css
- main.js

### Test Details:

- Finished Web App: https://screencast.com/t/UysTiuIjPM (needs flash)
- Screenshot: https://screencast.com/t/GQPrB14T

Using CSS and Javascript (JQuery), try to reproduce the functionnalities as seen on the above video.
Details can be found in main.js and style.css